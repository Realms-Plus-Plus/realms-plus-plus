/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.core.fluid.forge.imitator;

import com.google.common.base.MoreObjects;
import com.google.common.base.Suppliers;
import dev.architectury.core.fluid.ArchitecturyFluidAttributes;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidType;
import org.jetbrains.annotations.NotNull;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;

public abstract class ArchitecturyFlowingFluid extends BaseFlowingFluid {
    private static final Map<ArchitecturyFluidAttributes, FluidType> FLUID_TYPE_MAP = new IdentityHashMap<>();
    private final ArchitecturyFluidAttributes attributes;
    
    ArchitecturyFlowingFluid(ArchitecturyFluidAttributes attributes) {
        super(toForgeProperties(attributes));
        this.attributes = attributes;
    }
    
    private static Properties toForgeProperties(ArchitecturyFluidAttributes attributes) {
        Properties forge = new Properties(Suppliers.memoize(() -> {
            return FLUID_TYPE_MAP.computeIfAbsent(attributes, attr -> {
                return new ArchitecturyFluidAttributesForge(FluidType.Properties.create(), attr.getSourceFluid(), attr);
            });
        }), attributes::getSourceFluid, attributes::getFlowingFluid);
        forge.slopeFindDistance(attributes.getSlopeFindDistance());
        forge.levelDecreasePerBlock(attributes.getDropOff());
        forge.bucket(() -> MoreObjects.firstNonNull(attributes.getBucketItem(), Items.AIR));
        forge.tickRate(attributes.getTickDelay());
        forge.explosionResistance(attributes.getExplosionResistance());
        forge.block(() -> MoreObjects.firstNonNull(attributes.getBlock(), (FluidBlock) Blocks.WATER));
        return forge;
    }
    
    @Override
    public Fluid getFlowing() {
        return attributes.getFlowingFluid();
    }
    
    @Override
    public Fluid getStill() {
        return attributes.getSourceFluid();
    }
    
    @Override
    protected boolean isInfinite(World level) {
        return attributes.canConvertToSource();
    }
    
    @Override
    protected void beforeBreakingBlock(WorldAccess level, BlockPos pos, BlockState state) {
        // Same implementation as in WaterFluid.
        BlockEntity blockEntity = state.hasBlockEntity() ? level.getBlockEntity(pos) : null;
        Block.dropStacks(state, level, pos, blockEntity);
    }
    
    @Override
    protected int getMaxFlowDistance(WorldView level) {
        return attributes.getSlopeFindDistance(level);
    }
    
    @Override
    protected int getLevelDecreasePerBlock(WorldView level) {
        return attributes.getDropOff(level);
    }
    
    @Override
    public Item getBucketItem() {
        Item item = attributes.getBucketItem();
        return item == null ? Items.AIR : item;
    }
    
    @Override
    protected boolean canBeReplacedWith(FluidState state, BlockView level, BlockPos pos, Fluid fluid, Direction direction) {
        // Same implementation as in WaterFluid.
        return direction == Direction.DOWN && !this.matchesType(fluid);
    }
    
    @Override
    public int getTickRate(WorldView level) {
        return attributes.getTickDelay(level);
    }
    
    @Override
    protected float getBlastResistance() {
        return attributes.getExplosionResistance();
    }
    
    @Override
    protected BlockState toBlockState(FluidState state) {
        FluidBlock block = attributes.getBlock();
        if (block == null) return Blocks.AIR.getDefaultState();
        return block.getDefaultState().with(FluidBlock.LEVEL, getBlockStateLevel(state));
    }
    
    @NotNull
    @Override
    public Optional<SoundEvent> getBucketFillSound() {
        return Optional.ofNullable(attributes.getFillSound());
    }
    
    @Override
    public boolean matchesType(Fluid fluid) {
        return fluid == getStill() || fluid == getFlowing();
    }
    
    public static class Source extends ArchitecturyFlowingFluid {
        public Source(ArchitecturyFluidAttributes attributes) {
            super(attributes);
        }
        
        @Override
        public int getLevel(FluidState state) {
            return 8;
        }
        
        @Override
        public boolean isStill(FluidState state) {
            return true;
        }
    }
    
    public static class Flowing extends ArchitecturyFlowingFluid {
        public Flowing(ArchitecturyFluidAttributes attributes) {
            super(attributes);
            this.setDefaultState(this.getStateManager().getDefaultState().with(LEVEL, 7));
        }
        
        @Override
        protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
            super.appendProperties(builder);
            builder.add(LEVEL);
        }
        
        @Override
        public int getLevel(FluidState state) {
            return state.get(LEVEL);
        }
        
        @Override
        public boolean isStill(FluidState state) {
            return false;
        }
    }
}
