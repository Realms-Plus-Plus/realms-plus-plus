/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.forge;

import com.google.common.base.Suppliers;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import dev.architectury.platform.hooks.EventBusesHooks;
import dev.architectury.registry.CreativeTabOutput;
import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredSupplier;
import dev.architectury.utils.ArchitecturyConstants;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.CreativeModeTabRegistry;
import net.neoforged.neoforge.common.util.MutableHashedLinkedMap;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class CreativeTabRegistryImpl {
    private static final Logger LOGGER = LogManager.getLogger(CreativeTabRegistryImpl.class);
    
    private static final List<Consumer<BuildCreativeModeTabContentsEvent>> BUILD_CONTENTS_LISTENERS = new ArrayList<>();
    private static final Multimap<TabKey, Supplier<ItemStack>> APPENDS = MultimapBuilder.hashKeys().arrayListValues().build();
    
    static {
        EventBusesHooks.whenAvailable(ArchitecturyConstants.MOD_ID, bus -> {
            bus.addListener(CreativeTabRegistryImpl::event);
        });
        
        BUILD_CONTENTS_LISTENERS.add(event -> {
            for (Map.Entry<TabKey, Collection<Supplier<ItemStack>>> keyEntry : APPENDS.asMap().entrySet()) {
                Supplier<List<ItemStack>> stacks = Suppliers.memoize(() -> keyEntry.getValue().stream()
                        .map(Supplier::get)
                        .toList());
                if (keyEntry.getKey() instanceof TabKey.SupplierTabKey supplierTabKey) {
                    if (Objects.equals(CreativeModeTabRegistry.getName(event.getTab()), supplierTabKey.supplier().getId())) {
                        for (ItemStack stack : stacks.get()) {
                            event.add(stack, ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
                        }
                    }
                } else if (keyEntry.getKey() instanceof TabKey.DirectTabKey directTabKey) {
                    if (event.getTab().equals(directTabKey.tab())) {
                        for (ItemStack stack : stacks.get()) {
                            event.add(stack, ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
                        }
                    }
                }
            }
        });
    }
    
    public static void event(BuildCreativeModeTabContentsEvent event) {
        for (Consumer<BuildCreativeModeTabContentsEvent> listener : BUILD_CONTENTS_LISTENERS) {
            listener.accept(event);
        }
    }
    
    @ApiStatus.Experimental
    public static ItemGroup create(Consumer<ItemGroup.Builder> callback) {
        ItemGroup.Builder builder = ItemGroup.builder();
        callback.accept(builder);
        return builder.build();
    }
    
    @ApiStatus.Experimental
    public static DeferredSupplier<ItemGroup> ofBuiltin(ItemGroup tab) {
        Identifier key = Registries.ITEM_GROUP.getId(tab);
        if (key == null) {
            throw new IllegalArgumentException("Builtin tab %s is not registered!".formatted(tab));
        }
        return new DeferredSupplier<>() {
            @Override
            public Identifier getRegistryId() {
                return RegistryKeys.ITEM_GROUP.getValue();
            }
            
            @Override
            public Identifier getId() {
                return Registries.ITEM_GROUP.getId(tab);
            }
            
            @Override
            public boolean isPresent() {
                return true;
            }
            
            @Override
            public ItemGroup get() {
                return tab;
            }
        };
    }
    
    @ApiStatus.Experimental
    public static DeferredSupplier<ItemGroup> defer(Identifier name) {
        return new DeferredSupplier<>() {
            @Nullable
            private ItemGroup tab;
            
            @Override
            public Identifier getRegistryId() {
                return RegistryKeys.ITEM_GROUP.getValue();
            }
            
            @Override
            public Identifier getId() {
                return name;
            }
            
            @Override
            public ItemGroup get() {
                resolve();
                if (tab == null)
                    throw new IllegalStateException("Creative tab %s was not registered yet!".formatted(name));
                return tab;
            }
            
            @Override
            public boolean isPresent() {
                resolve();
                return tab != null;
            }
            
            private void resolve() {
                if (this.tab == null) {
                    this.tab = Registries.ITEM_GROUP.get(name);
                }
            }
        };
    }
    
    public static void modify(DeferredSupplier<ItemGroup> tab, CreativeTabRegistry.ModifyTabCallback filler) {
        BUILD_CONTENTS_LISTENERS.add(event -> {
            if (tab.isPresent()) {
                if (event.getTab().equals(tab.get())) {
                    filler.accept(event.getFlags(), wrapTabOutput(event), event.hasPermissions());
                }
            } else if (Objects.equals(CreativeModeTabRegistry.getName(event.getTab()), tab.getId())) {
                filler.accept(event.getFlags(), wrapTabOutput(event), event.hasPermissions());
            }
        });
    }
    
    private static CreativeTabOutput wrapTabOutput(BuildCreativeModeTabContentsEvent event) {
        return new CreativeTabOutput() {
            @Override
            public void acceptAfter(ItemStack after, ItemStack stack, ItemGroup.StackVisibility visibility) {
                event.insertAfter(after, stack, visibility);
            }
            
            @Override
            public void acceptBefore(ItemStack before, ItemStack stack, ItemGroup.StackVisibility visibility) {
                event.insertBefore(before, stack, visibility);
            }
        };
    }
    
    @ApiStatus.Experimental
    public static void appendStack(DeferredSupplier<ItemGroup> tab, Supplier<ItemStack> item) {
        APPENDS.put(new TabKey.SupplierTabKey(tab), item);
    }
    
    private interface TabKey {
        record SupplierTabKey(DeferredSupplier<ItemGroup> supplier) implements TabKey {
            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (!(o instanceof SupplierTabKey that)) return false;
                return Objects.equals(supplier.getId(), that.supplier.getId());
            }
            
            @Override
            public int hashCode() {
                return Objects.hash(supplier.getId());
            }
        }
        
        record DirectTabKey(ItemGroup tab) implements TabKey {
            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (!(o instanceof DirectTabKey that)) return false;
                return tab == that.tab;
            }
            
            @Override
            public int hashCode() {
                return System.identityHashCode(tab);
            }
        }
    }
}
