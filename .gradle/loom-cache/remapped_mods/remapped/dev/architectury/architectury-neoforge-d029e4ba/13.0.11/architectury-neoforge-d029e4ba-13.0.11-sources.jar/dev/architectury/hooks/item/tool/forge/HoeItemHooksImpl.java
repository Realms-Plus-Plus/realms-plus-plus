/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.item.tool.forge;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemUsageContext;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class HoeItemHooksImpl {
    public static void addTillable(Block input, Predicate<ItemUsageContext> predicate, Consumer<ItemUsageContext> action, Function<ItemUsageContext, BlockState> function) {
        NeoForge.EVENT_BUS.<BlockEvent.BlockToolModificationEvent>addListener(event -> {
            ItemUsageContext context = event.getContext();
            if (ItemAbilities.HOE_TILL == event.getItemAbility() && context.getStack().canPerformAction(ItemAbilities.HOE_TILL)
                    && event.getState().isOf(input) && predicate.test(context)) {
                if (!event.isSimulated()) {
                    action.accept(context);
                }
                
                event.setFinalState(function.apply(context));
            }
        });
    }
}
